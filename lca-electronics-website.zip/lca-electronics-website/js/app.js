/**
 * LCA Electronic Devices - Main Application Logic
 * Integrates data, interactive components, charts, and user controls.
 */

document.addEventListener("DOMContentLoaded", () => {
  const data = window.LCA_DATA;
  if (!data) {
    console.error("LCA_DATA not found. Ensure js/data.js is loaded.");
    return;
  }

  // State Management
  const state = {
    currentStageIndex: 0,
    selectedMaterial: data.materials[0],
    selectedDeviceIndex: 0,
    activeMfgStep: 0,
    activeComponentIndex: 0,
    usePhase: {
      gridIntensity: 420, // g CO2 / kWh
      hoursPerDay: 5,
      deviceYears: 3
    },
    lifetimeExtension: {
      baselineYears: 2.5,
      extendedYears: 5.0
    },
    calculator: {
      deviceKey: "smartphone",
      scenarioAYears: 2,
      scenarioBYears: 5,
      gridType: "average"
    },
    activeActionTab: "Consumers",
    finalTransformStep: 0
  };

  /* ========================================================================
     1. SCROLL PROGRESS & NAVIGATION
     ======================================================================== */
  const progressBar = document.getElementById("scroll-progress-bar");
  const backToTopBtn = document.getElementById("back-to-top-btn");
  const navLinks = document.querySelectorAll(".nav-link");
  const sections = document.querySelectorAll("section[id]");

  window.addEventListener("scroll", () => {
    const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = (window.scrollY / totalHeight) * 100;
    if (progressBar) progressBar.style.width = `${progress}%`;

    // Back to top button visibility
    if (backToTopBtn) {
      if (window.scrollY > 600) {
        backToTopBtn.classList.add("visible");
      } else {
        backToTopBtn.classList.remove("visible");
      }
    }

    // Active nav item highlighting
    let currentId = "";
    sections.forEach(sec => {
      const top = sec.offsetTop - 120;
      const height = sec.offsetHeight;
      if (window.scrollY >= top && window.scrollY < top + height) {
        currentId = sec.getAttribute("id");
      }
    });

    navLinks.forEach(link => {
      link.classList.remove("active");
      if (link.getAttribute("href") === `#${currentId}`) {
        link.classList.add("active");
      }
    });
  });

  if (backToTopBtn) {
    backToTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // Mobile Drawer Navigation
  const mobileToggleBtn = document.getElementById("mobile-menu-toggle");
  const mobileDrawer = document.getElementById("mobile-nav-drawer");
  const mobileNavLinks = document.querySelectorAll(".mobile-nav-link");

  if (mobileToggleBtn && mobileDrawer) {
    mobileToggleBtn.addEventListener("click", () => {
      const isOpen = mobileDrawer.classList.toggle("open");
      mobileToggleBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
      mobileToggleBtn.textContent = isOpen ? "✕" : "☰";
    });

    mobileNavLinks.forEach(link => {
      link.addEventListener("click", () => {
        mobileDrawer.classList.remove("open");
        mobileToggleBtn.setAttribute("aria-expanded", "false");
        mobileToggleBtn.textContent = "☰";
      });
    });
  }

  /* ========================================================================
     2. HERO DEVICE TRANSFORMATION INTERACTIVE PREVIEW
     ======================================================================== */
  const heroStepButtons = document.querySelectorAll(".hero-transform-nav .transform-step-btn");
  const heroImage = document.getElementById("hero-preview-img");
  const heroStageNum = document.getElementById("hero-stage-badge-num");
  const heroStageTitle = document.getElementById("hero-stage-title-text");
  const heroStageDesc = document.getElementById("hero-stage-desc-text");
  const heroMetric1 = document.getElementById("hero-m1-val");
  const heroMetric2 = document.getElementById("hero-m2-val");
  const heroMetric3 = document.getElementById("hero-m3-val");

  function updateHeroPreview(stageIdx) {
    const stage = data.stages[stageIdx];
    if (!stage) return;

    heroStepButtons.forEach((btn, i) => {
      btn.classList.toggle("active", i === stageIdx);
    });

    if (heroImage) {
      heroImage.src = stage.image;
      heroImage.alt = stage.title;
    }
    if (heroStageNum) heroStageNum.textContent = `PHASE ${stage.number} // ${stage.category.toUpperCase()}`;
    if (heroStageTitle) heroStageTitle.textContent = stage.title;
    if (heroStageDesc) heroStageDesc.textContent = stage.summary;

    if (stage.keyMetrics && stage.keyMetrics.length >= 3) {
      if (heroMetric1) heroMetric1.textContent = stage.keyMetrics[0].value;
      if (heroMetric2) heroMetric2.textContent = stage.keyMetrics[1].value;
      if (heroMetric3) heroMetric3.textContent = stage.keyMetrics[2].value;
    }
  }

  heroStepButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.getAttribute("data-stage-index"), 10);
      updateHeroPreview(idx);
    });
  });

  updateHeroPreview(0);

  /* ========================================================================
     3. CENTERPIECE: INTERACTIVE LIFE CYCLE JOURNEY (10 Stages)
     ======================================================================== */
  const stageTabsContainer = document.getElementById("lifecycle-stage-tabs");
  const stageNumEl = document.getElementById("stage-num-badge");
  const stageCategoryEl = document.getElementById("stage-category-text");
  const stageTitleEl = document.getElementById("stage-title-text");
  const stageSubtitleEl = document.getElementById("stage-subtitle-text");
  const stageSummaryEl = document.getElementById("stage-summary-text");
  const stageImageEl = document.getElementById("stage-main-image");
  const stageImageCaptionEl = document.getElementById("stage-image-caption-text");
  const stageMetricsContainer = document.getElementById("stage-metrics-container");
  const stageResourcesList = document.getElementById("stage-resources-list");
  const stageEmissionsList = document.getElementById("stage-emissions-list");
  const stageReductionsList = document.getElementById("stage-reductions-list");
  const stageStatVal = document.getElementById("stage-stat-val");
  const stageStatCtx = document.getElementById("stage-stat-ctx");
  const stageStatSrc = document.getElementById("stage-stat-src");

  // Render stage tabs
  if (stageTabsContainer) {
    stageTabsContainer.innerHTML = "";
    data.stages.forEach((stg, i) => {
      const tab = document.createElement("button");
      tab.className = `stage-tab-btn ${i === 0 ? "active" : ""}`;
      tab.setAttribute("data-stage-idx", i);
      tab.innerHTML = `
        <span class="stage-tab-num">${stg.number}</span>
        <span class="stage-tab-name">${stg.title.split(" ")[0]}</span>
      `;
      tab.addEventListener("click", () => {
        selectLifecycleStage(i);
      });
      stageTabsContainer.appendChild(tab);
    });
  }

  function selectLifecycleStage(idx) {
    state.currentStageIndex = idx;
    const stage = data.stages[idx];
    if (!stage) return;

    // Update Tab UI
    const allTabs = document.querySelectorAll(".stage-tab-btn");
    allTabs.forEach((t, i) => t.classList.toggle("active", i === idx));

    // Update Viewer Header
    if (stageNumEl) stageNumEl.textContent = `STAGE ${stage.number}`;
    if (stageCategoryEl) stageCategoryEl.textContent = stage.category;
    if (stageTitleEl) stageTitleEl.textContent = stage.title;
    if (stageSubtitleEl) stageSubtitleEl.textContent = stage.subtitle;
    if (stageSummaryEl) stageSummaryEl.textContent = stage.summary;

    // Update Image
    if (stageImageEl) {
      stageImageEl.src = stage.image;
      stageImageEl.alt = stage.title;
    }
    if (stageImageCaptionEl) stageImageCaptionEl.textContent = stage.imageCaption;

    // Update Metrics
    if (stageMetricsContainer) {
      stageMetricsContainer.innerHTML = stage.keyMetrics.map(m => `
        <div class="stage-metric-box">
          <span class="box-val">${m.value}</span>
          <span class="box-lbl">${m.label}</span>
          <span class="box-sub">${m.sub}</span>
        </div>
      `).join("");
    }

    // Update Resources
    if (stageResourcesList) {
      stageResourcesList.innerHTML = stage.resources.map(r => `
        <li><strong>${r.name}:</strong> ${r.share}</li>
      `).join("");
    }

    // Update Emissions
    if (stageEmissionsList) {
      stageEmissionsList.innerHTML = stage.emissionsAndImpacts.map(e => `
        <li>${e}</li>
      `).join("");
    }

    // Update Reductions
    if (stageReductionsList) {
      stageReductionsList.innerHTML = stage.reductionOpportunities.map(red => `
        <li>${red}</li>
      `).join("");
    }

    // Update Sourced Stat
    if (stageStatVal) stageStatVal.textContent = stage.statistic.value;
    if (stageStatCtx) stageStatCtx.textContent = stage.statistic.context;
    if (stageStatSrc) stageStatSrc.textContent = `Source: ${stage.statistic.source}`;
  }

  selectLifecycleStage(0);

  /* ========================================================================
     4. RAW MATERIAL EXTRACTION & INTERACTIVE MATERIAL MATRIX
     ======================================================================== */
  const matrixContainer = document.getElementById("periodic-matrix-grid");
  const inspectorSymbol = document.getElementById("mat-inspector-symbol");
  const inspectorName = document.getElementById("mat-inspector-name");
  const inspectorCategory = document.getElementById("mat-inspector-category");
  const inspectorUsage = document.getElementById("mat-inspector-usage");
  const inspectorMining = document.getElementById("mat-inspector-mining");
  const inspectorCarbon = document.getElementById("mat-inspector-carbon");
  const inspectorWater = document.getElementById("mat-inspector-water");
  const inspectorConcerns = document.getElementById("mat-inspector-concerns");
  const inspectorRecycling = document.getElementById("mat-inspector-recycling");

  function renderMaterialMatrix() {
    if (!matrixContainer) return;
    matrixContainer.innerHTML = "";

    data.materials.forEach((mat, idx) => {
      const card = document.createElement("div");
      card.className = `element-card ${idx === 0 ? "active" : ""}`;
      card.setAttribute("data-mat-index", idx);
      card.innerHTML = `
        <div class="element-card-top">
          <span class="element-atomic-num">${mat.atomicNumber}</span>
          <span class="element-category-tag">${mat.category}</span>
        </div>
        <div class="element-symbol">${mat.symbol}</div>
        <div class="element-name">${mat.name}</div>
      `;
      card.addEventListener("click", () => {
        selectMaterial(idx);
      });
      matrixContainer.appendChild(card);
    });
  }

  function selectMaterial(idx) {
    const mat = data.materials[idx];
    if (!mat) return;
    state.selectedMaterial = mat;

    const cards = document.querySelectorAll(".element-card");
    cards.forEach((c, i) => c.classList.toggle("active", i === idx));

    if (inspectorSymbol) inspectorSymbol.textContent = mat.symbol;
    if (inspectorName) inspectorName.textContent = mat.name;
    if (inspectorCategory) inspectorCategory.textContent = `${mat.category} • Atomic Number ${mat.atomicNumber}`;
    if (inspectorUsage) inspectorUsage.textContent = mat.typicalUsage;
    if (inspectorMining) inspectorMining.textContent = mat.primaryMiningHubs;
    if (inspectorCarbon) inspectorCarbon.textContent = mat.carbonIntensity;
    if (inspectorWater) inspectorWater.textContent = mat.waterIntensity;
    if (inspectorConcerns) inspectorConcerns.textContent = mat.environmentalConcerns;
    if (inspectorRecycling) inspectorRecycling.textContent = mat.recyclingPotential;
  }

  renderMaterialMatrix();
  selectMaterial(0);

  // Initialize Supply Chain Map
  if (window.LCA_CHARTS && document.getElementById("supply-chain-canvas")) {
    window.LCA_CHARTS.initSupplyChainMap("supply-chain-canvas", data.supplyChainNodes);
  }

  /* ========================================================================
     5. MANUFACTURING TRANSFORMATION PIPELINE
     ======================================================================== */
  const mfgSteps = [
    {
      title: "Raw Quartz Sand to Polysilicon",
      icon: "💎",
      desc: "Metallurgical grade silicon is refined to electronic-grade hyper-pure polysilicon (99.9999999% purity) using the Siemens chemical vapor deposition process at temperatures exceeding 1,100°C.",
      pills: ["Temperature: 1,150°C", "Purity: 9N (99.9999999%)", "Energy: ~120 kWh/kg polysilicon"],
      image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "Czochralski Ingot Growth & Wafer Slicing",
      icon: "🧪",
      desc: "Polysilicon is melted in quartz crucibles and pulled into single-crystal cylindrical ingots. Diamond wire saws slice the ingots into 300mm ultra-thin wafers with sub-micron thickness tolerances.",
      pills: ["Wafer Diameter: 300mm", "Thickness: 775 µm", "Kerf Loss: ~40% silicon dust"],
      image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "EUV Photolithography & Cleanroom Etching",
      icon: "🔬",
      desc: "Inside Class-1 cleanrooms, Extreme Ultraviolet (EUV) light at 13.5nm wavelength prints tens of billions of transistors per square centimeter. Fluorinated gases (NF₃, SF₆) etch microscopic circuit traces.",
      pills: ["Cleanroom Class: ISO Class 1", "Transistor Density: >150M / mm²", "Water Use: 30 L UPW / wafer"],
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "Multi-Layer PCB Lamination & Micro-Via Drilling",
      icon: "⚡",
      desc: "Woven glass fiber and epoxy resin sheets (FR-4) are laminated with high-purity copper foil. UV lasers drill micro-vias down to 50 microns to interconnect signal planes across 10–12 internal routing layers.",
      pills: ["PCB Layers: 10–12 Layers", "Via Diameter: 50–75 µm", "Copper Purity: 99.9%"],
      image: "https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "Battery Cell Winding & Electrolyte Infill",
      icon: "🔋",
      desc: "Lithium cobalt oxide (cathode) and synthetic graphite (anode) foils are wound or stacked with microporous polymer separators in ultra-dry rooms with <1% relative humidity, then vacuum-injected with LiPF₆ electrolyte.",
      pills: ["Dry Room RH: <1%", "Volumetric Density: 700 Wh/L", "Cathode: 100% Recycled Cobalt"],
      image: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "OLED Display Substrate Deposition",
      icon: "📱",
      desc: "Organic emitter molecules are thermally evaporated in high vacuum through Fine Metal Masks (FMM) onto flexible polyimide or thin glass substrates, sealed against moisture by inorganic barrier layers.",
      pills: ["Vacuum Level: 10⁻⁷ Torr", "Layer Thickness: <100 nm", "Pixel Pitch: 460+ PPI"],
      image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "Surface-Mount Technology & Final Integration",
      icon: "🤖",
      desc: "Robotic pick-and-place lines mount micro-components at over 50,000 placements per hour onto solder paste. Modules converge into CNC-milled aluminum chassis, undergoing automated optical and acoustic inspection.",
      pills: ["Placement Speed: 50k SMT/hr", "Zero Waste to Landfill", "100% Recycled Aluminum Enclosure"],
      image: "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1000&q=80"
    }
  ];

  const mfgNodesContainer = document.getElementById("pipeline-flow-nodes");
  const mfgTitle = document.getElementById("mfg-step-title");
  const mfgDesc = document.getElementById("mfg-step-desc");
  const mfgPillsContainer = document.getElementById("mfg-step-pills");
  const mfgImage = document.getElementById("mfg-step-image");

  if (mfgNodesContainer) {
    mfgNodesContainer.innerHTML = "";
    mfgSteps.forEach((step, idx) => {
      const node = document.createElement("div");
      node.className = `pipeline-step-node ${idx === 0 ? "active" : ""}`;
      node.setAttribute("data-step-idx", idx);
      node.innerHTML = `
        <span class="pipeline-icon">${step.icon}</span>
        <span class="pipeline-node-name">${step.title.split(" ")[0]}</span>
      `;
      node.addEventListener("click", () => {
        selectMfgStep(idx);
      });
      mfgNodesContainer.appendChild(node);

      if (idx < mfgSteps.length - 1) {
        const arrow = document.createElement("span");
        arrow.className = "pipeline-connector-arrow";
        arrow.innerHTML = "→";
        mfgNodesContainer.appendChild(arrow);
      }
    });
  }

  function selectMfgStep(idx) {
    const step = mfgSteps[idx];
    if (!step) return;
    state.activeMfgStep = idx;

    const allNodes = document.querySelectorAll(".pipeline-step-node");
    allNodes.forEach((n, i) => n.classList.toggle("active", i === idx));

    if (mfgTitle) mfgTitle.textContent = step.title;
    if (mfgDesc) mfgDesc.textContent = step.desc;
    if (mfgImage) {
      mfgImage.src = step.image;
      mfgImage.alt = step.title;
    }
    if (mfgPillsContainer) {
      mfgPillsContainer.innerHTML = step.pills.map(p => `
        <span class="data-pill">${p}</span>
      `).join("");
    }
  }

  selectMfgStep(0);

  /* ========================================================================
     6. ENVIRONMENTAL IMPACT DASHBOARD & CHARTS
     ======================================================================== */
  const deviceFilterButtons = document.querySelectorAll(".device-filter-btn");
  const kpiCarbonVal = document.getElementById("kpi-carbon-val");
  const kpiEnergyVal = document.getElementById("kpi-energy-val");
  const kpiWaterVal = document.getElementById("kpi-water-val");
  const kpiOreVal = document.getElementById("kpi-ore-val");

  function updateImpactDashboard(deviceIdx) {
    state.selectedDeviceIndex = deviceIdx;
    const device = data.deviceComparisonData[deviceIdx];
    if (!device) return;

    deviceFilterButtons.forEach((btn, i) => btn.classList.toggle("active", i === deviceIdx));

    if (kpiCarbonVal) kpiCarbonVal.textContent = device.embodiedCarbon;
    if (kpiEnergyVal) kpiEnergyVal.textContent = device.totalPrimaryEnergy;
    if (kpiWaterVal) kpiWaterVal.textContent = (device.waterFootprint / 1000).toFixed(1);
    if (kpiOreVal) kpiOreVal.textContent = device.oreExtracted;

    // Render Charts
    if (window.LCA_CHARTS) {
      const footprintData = deviceIdx === 1 ? data.footprintDistribution.laptop : data.footprintDistribution.smartphone;
      window.LCA_CHARTS.renderDonutChart("carbon-donut-chart", footprintData, {
        centerValue: `${device.embodiedCarbon} kg`,
        centerLabel: "CO₂e Total"
      });
      window.LCA_CHARTS.renderBarChart("comparison-bar-chart", data.deviceComparisonData, deviceIdx);
    }
  }

  deviceFilterButtons.forEach((btn, idx) => {
    btn.addEventListener("click", () => updateImpactDashboard(idx));
  });

  updateImpactDashboard(0);

  /* ========================================================================
     7. WHAT'S INSIDE YOUR DEVICE? (Exploded View Interactive Anatomy)
     ======================================================================== */
  const layerPlates = document.querySelectorAll(".exploded-layer-plate");
  const compNameEl = document.getElementById("comp-name-text");
  const compShareEl = document.getElementById("comp-carbon-share-badge");
  const compMaterialsContainer = document.getElementById("comp-materials-tags");
  const compFunctionEl = document.getElementById("comp-function-text");
  const compRepairEl = document.getElementById("comp-repair-text");
  const compRecycleEl = document.getElementById("comp-recycle-text");
  const compCircularEl = document.getElementById("comp-circular-text");

  function selectExplodedComponent(idx) {
    const comp = data.explodedComponents[idx];
    if (!comp) return;
    state.activeComponentIndex = idx;

    layerPlates.forEach((plate, i) => plate.classList.toggle("active", i === idx));

    if (compNameEl) compNameEl.textContent = comp.name;
    if (compShareEl) compShareEl.textContent = comp.carbonShare;
    if (compFunctionEl) compFunctionEl.textContent = comp.function;
    if (compRepairEl) compRepairEl.textContent = comp.repairabilityNotes;
    if (compRecycleEl) compRecycleEl.textContent = comp.recyclingYield;
    if (compCircularEl) compCircularEl.textContent = comp.circularSolution;

    if (compMaterialsContainer) {
      compMaterialsContainer.innerHTML = comp.materials.map(m => `
        <span class="material-tag">${m}</span>
      `).join("");
    }
  }

  layerPlates.forEach((plate, idx) => {
    plate.addEventListener("click", () => selectExplodedComponent(idx));
  });

  selectExplodedComponent(0);

  /* ========================================================================
     8. CONSUMER USE PHASE SIMULATOR
     ======================================================================== */
  const gridSlider = document.getElementById("grid-carbon-slider");
  const gridValueDisplay = document.getElementById("grid-carbon-value");
  const hoursSlider = document.getElementById("use-hours-slider");
  const hoursValueDisplay = document.getElementById("use-hours-value");
  const yearsSlider = document.getElementById("use-years-slider");
  const yearsValueDisplay = document.getElementById("use-years-value");
  const annualEnergyOutput = document.getElementById("annual-energy-output");
  const lifetimeEmissionsOutput = document.getElementById("lifetime-emissions-output");

  function updateUsePhaseSimulation() {
    const gridGrams = parseInt(gridSlider ? gridSlider.value : 420, 10);
    const hours = parseFloat(hoursSlider ? hoursSlider.value : 5);
    const years = parseFloat(yearsSlider ? yearsSlider.value : 3);

    if (gridValueDisplay) gridValueDisplay.textContent = `${gridGrams} g CO₂/kWh`;
    if (hoursValueDisplay) hoursValueDisplay.textContent = `${hours} hrs/day`;
    if (yearsValueDisplay) yearsValueDisplay.textContent = `${years} yrs`;

    // Typical active draw: ~4W average charging & operational usage
    const dailyKWh = (hours * 4) / 1000;
    const annualKWh = dailyKWh * 365;
    const lifetimeCO2 = (annualKWh * years * (gridGrams / 1000));

    if (annualEnergyOutput) annualEnergyOutput.textContent = `${annualKWh.toFixed(1)} kWh`;
    if (lifetimeEmissionsOutput) lifetimeEmissionsOutput.textContent = `${lifetimeCO2.toFixed(1)} kg`;
  }

  if (gridSlider) gridSlider.addEventListener("input", updateUsePhaseSimulation);
  if (hoursSlider) hoursSlider.addEventListener("input", updateUsePhaseSimulation);
  if (yearsSlider) yearsSlider.addEventListener("input", updateUsePhaseSimulation);
  updateUsePhaseSimulation();

  /* ========================================================================
     9. LIFETIME EXTENSION SIMULATOR
     ======================================================================== */
  const lifeSlider = document.getElementById("device-life-slider");
  const lifeSliderVal = document.getElementById("device-life-slider-val");
  const carbonSavingsPct = document.getElementById("extension-savings-pct");
  const oreSavedVal = document.getElementById("extension-ore-saved");

  function updateLifetimeExtension() {
    const years = parseFloat(lifeSlider ? lifeSlider.value : 4);
    if (lifeSliderVal) lifeSliderVal.textContent = `${years.toFixed(1)} Years`;

    // Baseline smartphone is 2.5 years.
    // Annualized manufacturing footprint: 65 kg / years
    const baselineAnnualMfg = 65 / 2.5; // 26 kg CO2e / year
    const newAnnualMfg = 65 / years;
    const savingsPct = Math.round(((baselineAnnualMfg - newAnnualMfg) / baselineAnnualMfg) * 100);
    const oreSaved = ((years - 2.5) * 13.6).toFixed(1);

    if (carbonSavingsPct) carbonSavingsPct.textContent = `${Math.max(0, savingsPct)}%`;
    if (oreSavedVal) oreSavedVal.textContent = `${Math.max(0, oreSaved)} kg`;
  }

  if (lifeSlider) lifeSlider.addEventListener("input", updateLifetimeExtension);
  updateLifetimeExtension();

  /* ========================================================================
     10. INDUSTRIAL RECYCLING PROCESS FLOW (8 Steps)
     ======================================================================== */
  const recyclingGrid = document.getElementById("recycling-steps-grid");
  if (recyclingGrid) {
    recyclingGrid.innerHTML = data.recyclingSteps.map(s => `
      <div class="recycle-step-card">
        <div class="recycle-step-header">
          <span class="recycle-step-num">STEP 0${s.step}</span>
        </div>
        <div class="recycle-step-title">${s.title}</div>
        <div class="recycle-step-desc">${s.detail}</div>
      </div>
    `).join("");
  }

  /* ========================================================================
     11. INTERACTIVE LCA CALCULATOR / EXPLORER
     ======================================================================== */
  const calcDeviceSelect = document.getElementById("calc-device-select");
  const calcGridSelect = document.getElementById("calc-grid-select");
  const calcScenarioAYears = document.getElementById("calc-scenario-a-years");
  const calcScenarioBYears = document.getElementById("calc-scenario-b-years");

  const scAAnnualCO2 = document.getElementById("sc-a-annual-co2");
  const scBAnnualCO2 = document.getElementById("sc-b-annual-co2");
  const scSavingsPct = document.getElementById("sc-savings-pct");
  const scTreesEq = document.getElementById("sc-trees-eq");

  function updateLcaCalculator() {
    const devType = calcDeviceSelect ? calcDeviceSelect.value : "smartphone";
    const yearsA = parseFloat(calcScenarioAYears ? calcScenarioAYears.value : 2);
    const yearsB = parseFloat(calcScenarioBYears ? calcScenarioBYears.value : 5);
    const gridType = calcGridSelect ? calcGridSelect.value : "average";

    let gridFactor = 0.42; // kg CO2 / kWh
    if (gridType === "clean") gridFactor = 0.08;
    if (gridType === "fossil") gridFactor = 0.75;

    let embodied = 65; // kg CO2e
    let annualKWh = 3.5;
    if (devType === "laptop") { embodied = 210; annualKWh = 55; }
    if (devType === "tablet") { embodied = 105; annualKWh = 14; }
    if (devType === "desktop") { embodied = 480; annualKWh = 210; }

    // Scenario A Annualized Footprint
    const annualA = (embodied / yearsA) + (annualKWh * gridFactor);
    // Scenario B Annualized Footprint (extended with slight battery refurbishment allowance +3kg)
    const annualB = ((embodied + 3) / yearsB) + (annualKWh * gridFactor);

    const savings = Math.max(0, Math.round(((annualA - annualB) / annualA) * 100));
    // 1 urban tree absorbs ~22 kg CO2 per year
    const trees = (((annualA - annualB) * 5) / 22).toFixed(1);

    if (scAAnnualCO2) scAAnnualCO2.textContent = `${annualA.toFixed(1)} kg CO₂e / yr`;
    if (scBAnnualCO2) scBAnnualCO2.textContent = `${annualB.toFixed(1)} kg CO₂e / yr`;
    if (scSavingsPct) scSavingsPct.textContent = `${savings}% Carbon Avoidance`;
    if (scTreesEq) scTreesEq.textContent = `Equivalent to ~${trees} tree seedlings grown for 10 years`;
  }

  if (calcDeviceSelect) calcDeviceSelect.addEventListener("change", updateLcaCalculator);
  if (calcGridSelect) calcGridSelect.addEventListener("change", updateLcaCalculator);
  if (calcScenarioAYears) calcScenarioAYears.addEventListener("change", updateLcaCalculator);
  if (calcScenarioBYears) calcScenarioBYears.addEventListener("change", updateLcaCalculator);
  updateLcaCalculator();

  /* ========================================================================
     12. ACTION GUIDE TABS
     ======================================================================== */
  const actionTabButtons = document.querySelectorAll(".action-tab-btn");
  const actionCardsGrid = document.getElementById("action-cards-grid");

  function renderActionCards(groupName) {
    if (!actionCardsGrid) return;
    actionTabButtons.forEach(btn => {
      btn.classList.toggle("active", btn.getAttribute("data-tab") === groupName);
    });

    const group = data.actionGuide.find(g => g.group.includes(groupName));
    if (!group) return;

    actionCardsGrid.innerHTML = group.actions.map(act => `
      <div class="action-card">
        <h4>${act.title}</h4>
        <p>${act.text}</p>
      </div>
    `).join("");
  }

  actionTabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const tabName = btn.getAttribute("data-tab");
      renderActionCards(tabName);
    });
  });

  renderActionCards("Consumers");

  /* ========================================================================
     13. FINAL TRANSFORMATION EXPERIENCE SCRUBBER
     ======================================================================== */
  const finalSlider = document.getElementById("final-transform-slider");
  const finalBadge = document.getElementById("final-stage-badge");
  const finalTitle = document.getElementById("final-stage-title");
  const finalDesc = document.getElementById("final-stage-desc");

  const finalStages = [
    {
      badge: "STATE 01 // FACTORY FRESH",
      title: "NEW DEVICE",
      desc: "Freshly unboxed. 70–80% of its lifetime greenhouse gas emissions are already locked inside, embodied in silicon wafers and refined metals."
    },
    {
      badge: "STATE 02 // IN OPERATION",
      title: "USED DEVICE",
      desc: "Daily charging, drops, and software updates. Battery capacity gradually reduces to 80% over 800 charge cycles."
    },
    {
      badge: "STATE 03 // LIFETIME EXTENSION",
      title: "REPAIRED DEVICE",
      desc: "A fresh replacement battery and new display glass installed. Avoids the release of over 50 kg of carbon needed for an unnecessary new replacement."
    },
    {
      badge: "STATE 04 // SECOND LIFE",
      title: "REFURBISHED DEVICE",
      desc: "Sanitized, diagnostically certified, and resold on the secondary market. Displaces virgin manufacturing demand for a second owner."
    },
    {
      badge: "STATE 05 // END OF LIFE",
      title: "DISASSEMBLED DEVICE",
      desc: "Harvested by robotic arms or manual disassembly. Batteries, camera modules, and logic boards segregated before shredding."
    },
    {
      badge: "STATE 06 // METALLURGICAL SMELTING",
      title: "RECOVERED MATERIALS",
      desc: "High-temperature hydrometallurgical recovery yielding 99.99% pure gold, certified secondary copper, and battery-grade lithium."
    },
    {
      badge: "STATE 07 // CLOSED LOOP",
      title: "NEW CIRCULAR PRODUCT",
      desc: "Recovered secondary alloys re-enter Tier-1 factories as chassis billets and solder paste. Zero new virgin ore mined."
    }
  ];

  function updateFinalTransform(stepIdx) {
    const stg = finalStages[stepIdx];
    if (!stg) return;
    if (finalBadge) finalBadge.textContent = stg.badge;
    if (finalTitle) finalTitle.textContent = stg.title;
    if (finalDesc) finalDesc.textContent = stg.desc;
  }

  if (finalSlider) {
    finalSlider.addEventListener("input", (e) => {
      updateFinalTransform(parseInt(e.target.value, 10));
    });
  }
  updateFinalTransform(0);

  /* ========================================================================
     14. SOURCES & METHODOLOGY SEARCH FILTER
     ======================================================================== */
  const biblioList = document.getElementById("biblio-list");
  const biblioSearch = document.getElementById("sources-search-input");

  function renderBibliography(filterText = "") {
    if (!biblioList) return;
    const lower = filterText.toLowerCase();
    const filtered = data.bibliography.filter(b => 
      b.title.toLowerCase().includes(lower) ||
      b.author.toLowerCase().includes(lower) ||
      b.organization.toLowerCase().includes(lower) ||
      b.verifiedDataPoints.toLowerCase().includes(lower)
    );

    biblioList.innerHTML = filtered.map(b => `
      <div class="biblio-card">
        <div>
          <div class="biblio-title">${b.title}</div>
          <div class="biblio-author">${b.author} • ${b.organization}</div>
          <div class="biblio-datapoints"><strong>Verified Data Points:</strong> ${b.verifiedDataPoints}</div>
        </div>
        <div class="biblio-meta-right">
          <span class="biblio-year">${b.year}</span>
          <span class="biblio-doi">${b.doi}</span>
          <a href="${b.url}" target="_blank" rel="noopener noreferrer" class="biblio-link-btn">
            View Report ↗
          </a>
        </div>
      </div>
    `).join("");
  }

  if (biblioSearch) {
    biblioSearch.addEventListener("input", (e) => {
      renderBibliography(e.target.value);
    });
  }
  renderBibliography();

});
