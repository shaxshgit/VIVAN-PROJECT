/**
 * LCA Charts & Visualizations Engine
 * Lightweight, high-precision SVG and Canvas rendering for scientific telemetry
 * Optimized for Bright / Modern Light Theme with Vibrant Accents
 */

const LCA_CHARTS = {
  // Render Interactive Donut Chart for Footprint Breakdown
  renderDonutChart(containerId, data, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = "";

    const width = options.width || container.clientWidth || 340;
    const height = options.height || container.clientHeight || 300;
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.min(width, height) / 2 - 25;
    const innerRadius = radius * 0.62;

    const total = data.reduce((acc, d) => acc + d.share, 0);
    let startAngle = -Math.PI / 2;

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");
    svg.style.overflow = "visible";

    data.forEach((item, idx) => {
      const sliceAngle = (item.share / total) * (Math.PI * 2);
      const endAngle = startAngle + sliceAngle;

      const x1 = cx + radius * Math.cos(startAngle);
      const y1 = cy + radius * Math.sin(startAngle);
      const x2 = cx + radius * Math.cos(endAngle);
      const y2 = cy + radius * Math.sin(endAngle);

      const ix1 = cx + innerRadius * Math.cos(endAngle);
      const iy1 = cy + innerRadius * Math.sin(endAngle);
      const ix2 = cx + innerRadius * Math.cos(startAngle);
      const iy2 = cy + innerRadius * Math.sin(startAngle);

      const largeArc = sliceAngle > Math.PI ? 1 : 0;

      const pathData = [
        `M ${x1} ${y1}`,
        `A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}`,
        `L ${ix1} ${iy1}`,
        `A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${ix2} ${iy2}`,
        "Z"
      ].join(" ");

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", pathData);
      path.setAttribute("fill", item.color || "#10b981");
      path.setAttribute("stroke", "#ffffff");
      path.setAttribute("stroke-width", "3");
      path.style.cursor = "pointer";
      path.style.transition = "transform 0.2s ease, opacity 0.2s ease";

      path.addEventListener("mouseenter", (e) => {
        path.setAttribute("opacity", "0.88");
        path.setAttribute("transform", `scale(1.03) translate(${-cx * 0.03}, ${-cy * 0.03})`);
        if (options.onHover) options.onHover(item, e);
      });

      path.addEventListener("mouseleave", () => {
        path.setAttribute("opacity", "1");
        path.removeAttribute("transform");
        if (options.onLeave) options.onLeave();
      });

      svg.appendChild(path);
      startAngle = endAngle;
    });

    // Center text (crisp dark slate typography)
    const textGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
    textGroup.setAttribute("text-anchor", "middle");

    const textVal = document.createElementNS("http://www.w3.org/2000/svg", "text");
    textVal.setAttribute("x", cx);
    textVal.setAttribute("y", cy - 2);
    textVal.setAttribute("fill", "#0f172a");
    textVal.setAttribute("font-size", "22");
    textVal.setAttribute("font-weight", "800");
    textVal.setAttribute("font-family", "JetBrains Mono, monospace");
    textVal.textContent = options.centerValue || "100%";

    const textSub = document.createElementNS("http://www.w3.org/2000/svg", "text");
    textSub.setAttribute("x", cx);
    textSub.setAttribute("y", cy + 18);
    textSub.setAttribute("fill", "#64748b");
    textSub.setAttribute("font-size", "11");
    textSub.setAttribute("font-weight", "600");
    textSub.setAttribute("font-family", "Plus Jakarta Sans, sans-serif");
    textSub.textContent = options.centerLabel || "Emissions";

    textGroup.appendChild(textVal);
    textGroup.appendChild(textSub);
    svg.appendChild(textGroup);

    container.appendChild(svg);
  },

  // Render Comparative Stacked Bar Chart for Device Comparison
  renderBarChart(containerId, devicesData, selectedIndex = 0) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = "";

    const width = container.clientWidth || 480;
    const height = container.clientHeight || 300;
    const padding = { top: 25, right: 35, bottom: 45, left: 110 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const maxVal = Math.max(...devicesData.map(d => d.embodiedCarbon + (d.annualUseCarbon * d.expectedLifetime))) * 1.15;

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");

    const barHeight = 28;
    const barSpacing = chartH / devicesData.length;

    devicesData.forEach((device, i) => {
      const y = padding.top + i * barSpacing + (barSpacing - barHeight) / 2;
      const embodiedW = (device.embodiedCarbon / maxVal) * chartW;
      const useW = ((device.annualUseCarbon * device.expectedLifetime) / maxVal) * chartW;
      const isSelected = i === selectedIndex;

      // Label (Device name)
      const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
      label.setAttribute("x", padding.left - 12);
      label.setAttribute("y", y + barHeight / 2 + 4);
      label.setAttribute("text-anchor", "end");
      label.setAttribute("fill", isSelected ? "#0f172a" : "#64748b");
      label.setAttribute("font-size", "11");
      label.setAttribute("font-weight", isSelected ? "800" : "600");
      label.setAttribute("font-family", "Plus Jakarta Sans, sans-serif");
      // Truncate name for fit
      const shortName = device.category.split(" ")[0];
      label.textContent = shortName;
      svg.appendChild(label);

      // Embodied Carbon bar (Vibrant Electric Blue)
      const rectEmbodied = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      rectEmbodied.setAttribute("x", padding.left);
      rectEmbodied.setAttribute("y", y);
      rectEmbodied.setAttribute("width", embodiedW);
      rectEmbodied.setAttribute("height", barHeight);
      rectEmbodied.setAttribute("fill", isSelected ? "#0284c7" : "#38bdf8");
      rectEmbodied.setAttribute("rx", "4");
      svg.appendChild(rectEmbodied);

      // Use Phase bar (stacked, Vibrant Emerald Green)
      const rectUse = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      rectUse.setAttribute("x", padding.left + embodiedW + 2);
      rectUse.setAttribute("y", y);
      rectUse.setAttribute("width", useW);
      rectUse.setAttribute("height", barHeight);
      rectUse.setAttribute("fill", isSelected ? "#059669" : "#34d399");
      rectUse.setAttribute("rx", "4");
      svg.appendChild(rectUse);

      // Value text label at the end
      const totalVal = Math.round(device.embodiedCarbon + (device.annualUseCarbon * device.expectedLifetime));
      const valText = document.createElementNS("http://www.w3.org/2000/svg", "text");
      valText.setAttribute("x", padding.left + embodiedW + useW + 10);
      valText.setAttribute("y", y + barHeight / 2 + 4);
      valText.setAttribute("fill", "#0f172a");
      valText.setAttribute("font-size", "11");
      valText.setAttribute("font-weight", "700");
      valText.setAttribute("font-family", "JetBrains Mono, monospace");
      valText.textContent = `${totalVal} kg`;
      svg.appendChild(valText);
    });

    // Legend at bottom
    const legG = document.createElementNS("http://www.w3.org/2000/svg", "g");
    legG.setAttribute("transform", `translate(${padding.left}, ${height - 10})`);

    legG.innerHTML = `
      <rect x="0" y="-8" width="12" height="12" rx="3" fill="#0284c7" />
      <text x="16" y="2" fill="#334155" font-size="11" font-weight="600" font-family="Plus Jakarta Sans">Embodied (Mfg)</text>
      <rect x="135" y="-8" width="12" height="12" rx="3" fill="#059669" />
      <text x="151" y="2" fill="#334155" font-size="11" font-weight="600" font-family="Plus Jakarta Sans">Use Phase</text>
    `;
    svg.appendChild(legG);

    container.appendChild(svg);
  },

  // Interactive Supply Chain Canvas World Map (Bright Modern Cartography)
  initSupplyChainMap(canvasId, nodes, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    let width = canvas.parentElement.clientWidth;
    let height = canvas.parentElement.clientHeight;
    canvas.width = width * window.devicePixelRatio;
    canvas.height = height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    let animationFrame;
    let pulsePhase = 0;
    let hoveredNode = null;

    // Convert Geo Lat/Long to Equirectangular Screen Coordinates
    function geoToScreen(lat, lng) {
      const x = ((lng + 180) / 360) * width;
      const latRad = (lat * Math.PI) / 180;
      const mercN = Math.log(Math.tan(Math.PI / 4 + latRad / 2));
      const y = height / 2 - (mercN * height) / (2 * Math.PI);
      return {
        x: Math.max(20, Math.min(width - 20, x)),
        y: Math.max(30, Math.min(height - 30, y * 0.85 + 40))
      };
    }

    // Stylized Continent Landmasses
    const stylizedContinents = [
      // North America
      [[-160, 65], [-120, 68], [-80, 70], [-60, 50], [-70, 40], [-80, 25], [-100, 20], [-120, 35], [-130, 55], [-160, 65]],
      // South America
      [[-75, 10], [-50, -5], [-35, -5], [-40, -25], [-65, -50], [-75, -40], [-80, -5], [-75, 10]],
      // Europe
      [[-10, 36], [0, 45], [10, 55], [30, 65], [40, 55], [30, 40], [10, 36], [-10, 36]],
      // Africa
      [[-15, 30], [20, 32], [45, 12], [40, -10], [30, -32], [18, -34], [10, 5], [-15, 15], [-15, 30]],
      // Asia
      [[40, 55], [80, 70], [130, 65], [145, 45], [120, 30], [100, 10], [75, 10], [50, 25], [40, 55]],
      // Australia
      [[115, -20], [150, -20], [150, -38], [115, -35], [115, -20]]
    ];

    function drawWorldMap() {
      ctx.clearRect(0, 0, width, height);

      // Light subtle ocean grid lines
      ctx.strokeStyle = "rgba(148, 163, 184, 0.18)";
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 60) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 50) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw stylized continent landmasses in crisp soft-slate
      ctx.fillStyle = "rgba(226, 232, 240, 0.85)";
      ctx.strokeStyle = "rgba(203, 213, 225, 0.95)";
      ctx.lineWidth = 1.5;

      stylizedContinents.forEach(poly => {
        ctx.beginPath();
        poly.forEach((pt, idx) => {
          const s = geoToScreen(pt[1], pt[0]);
          if (idx === 0) ctx.moveTo(s.x, s.y);
          else ctx.lineTo(s.x, s.y);
        });
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      });

      // Draw Supply Lines (Arched Curves)
      nodes.forEach(node => {
        if (!node.destinationHubs || !node.destinationHubs.length) return;
        const startPos = geoToScreen(node.lat, node.lng);

        node.destinationHubs.forEach(destId => {
          const destNode = nodes.find(n => n.id === destId);
          if (!destNode) return;
          const endPos = geoToScreen(destNode.lat, destNode.lng);

          const midX = (startPos.x + endPos.x) / 2;
          const midY = Math.min(startPos.y, endPos.y) - 35;

          // Vibrant curved route line
          ctx.beginPath();
          ctx.moveTo(startPos.x, startPos.y);
          ctx.quadraticCurveTo(midX, midY, endPos.x, endPos.y);
          ctx.strokeStyle = "rgba(2, 132, 199, 0.45)";
          ctx.lineWidth = 1.75;
          ctx.setLineDash([4, 4]);
          ctx.stroke();
          ctx.setLineDash([]);

          // Animated bright particle
          const t = (pulsePhase % 100) / 100;
          const px = Math.pow(1 - t, 2) * startPos.x + 2 * (1 - t) * t * midX + Math.pow(t, 2) * endPos.x;
          const py = Math.pow(1 - t, 2) * startPos.y + 2 * (1 - t) * t * midY + Math.pow(t, 2) * endPos.y;

          ctx.beginPath();
          ctx.arc(px, py, 3, 0, Math.PI * 2);
          ctx.fillStyle = "#0284c7";
          ctx.shadowColor = "rgba(2, 132, 199, 0.6)";
          ctx.shadowBlur = 6;
          ctx.fill();
          ctx.shadowBlur = 0;
        });
      });

      // Draw Supply Nodes
      nodes.forEach(node => {
        const pos = geoToScreen(node.lat, node.lng);
        const isHovered = hoveredNode && hoveredNode.id === node.id;

        // Vibrant colors by category
        let color = "#ea580c"; // extraction
        if (node.category.includes("Semiconductor") || node.category.includes("Fab")) color = "#0284c7";
        if (node.category.includes("Assembly")) color = "#059669";
        if (node.category.includes("Recycle")) color = "#7c3aed";
        if (node.category.includes("Distribution")) color = "#0891b2";

        // Pulsing ring
        ctx.beginPath();
        const pulseRadius = 5 + Math.sin(pulsePhase * 0.05) * 3;
        ctx.arc(pos.x, pos.y, isHovered ? 13 : pulseRadius + 3, 0, Math.PI * 2);
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Inner solid core
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, isHovered ? 6 : 4.5, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();

        // City / Region label in readable dark font
        ctx.font = isHovered ? "bold 11px Plus Jakarta Sans" : "600 9.5px Plus Jakarta Sans";
        ctx.fillStyle = isHovered ? "#0f172a" : "#334155";
        ctx.textAlign = "center";
        ctx.fillText(node.name.split(" ")[0], pos.x, pos.y + (isHovered ? 19 : 15));
      });

      pulsePhase += 0.8;
      animationFrame = requestAnimationFrame(drawWorldMap);
    }

    drawWorldMap();

    // Mouse Move Hover Interaction
    const tooltip = document.getElementById("supply-chain-tooltip");

    canvas.addEventListener("mousemove", (e) => {
      const rect = canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      let found = null;
      for (const node of nodes) {
        const pos = geoToScreen(node.lat, node.lng);
        const dist = Math.hypot(mouseX - pos.x, mouseY - pos.y);
        if (dist < 14) {
          found = node;
          break;
        }
      }

      hoveredNode = found;

      if (found && tooltip) {
        tooltip.innerHTML = `
          <div style="font-family: JetBrains Mono; font-size: 0.72rem; color: #0284c7; font-weight: 700; text-transform: uppercase;">${found.category}</div>
          <div style="font-weight: 800; font-size: 1rem; color: #0f172a; margin: 3px 0;">${found.name}</div>
          <div style="color: #64748b; font-size: 0.8rem; margin-bottom: 6px;">${found.country}</div>
          <div style="font-size: 0.82rem; line-height: 1.45; color: #334155;">${found.description}</div>
          <div style="margin-top: 6px; font-size: 0.75rem; color: #059669; font-weight: 600;"><strong>Key Output:</strong> ${found.primaryOutputs}</div>
        `;
        tooltip.style.left = `${e.clientX - rect.left}px`;
        tooltip.style.top = `${e.clientY - rect.top - 15}px`;
        tooltip.classList.add("visible");
      } else if (tooltip) {
        tooltip.classList.remove("visible");
      }
    });

    canvas.addEventListener("mouseleave", () => {
      hoveredNode = null;
      if (tooltip) tooltip.classList.remove("visible");
    });

    window.addEventListener("resize", () => {
      width = canvas.parentElement.clientWidth;
      height = canvas.parentElement.clientHeight;
      canvas.width = width * window.devicePixelRatio;
      canvas.height = height * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    });

    return {
      destroy: () => cancelAnimationFrame(animationFrame)
    };
  }
};

if (typeof window !== "undefined") {
  window.LCA_CHARTS = LCA_CHARTS;
}
